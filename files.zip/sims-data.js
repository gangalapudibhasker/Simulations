/*
  ============================================================
  HOW TO ADD A NEW SIMULATION
  ============================================================
  1. Find your class number below (6, 7, 8, 9, or 10).
  2. Copy this line into that class's array:

     { title: "Name", chapter: "Ch 4 · Simple Equations", description: "One line about what it does.", url: "simple-equations.html" },

  3. Save the file. The home page count and the class page
     listing update automatically — nothing else to touch.

  "url" can be a link to a page on this same site (upload the
  simulation's .html file next to these pages) or a full link
  starting with https:// if it lives somewhere else.
  ============================================================
*/

const CLASS_INFO = {
  6: "Ratio, integers and the first steps into geometry.",
  7: "Rational numbers, algebra begins, and practical geometry.",
  8: "Exponents, factorisation, and mensuration in 3D.",
  9: "Coordinate geometry, polynomials, and circle theorems.",
  10: "Trigonometry, quadratic equations, and board-exam prep.",
};

const SIMULATIONS = {
  6: [
    // Example — delete or edit once you have real ones:
    // { title: "Number Line Explorer", chapter: "Ch 1 · Knowing Our Numbers", description: "Slide, jump and compare whole numbers on an interactive line.", url: "#" },
  ],
  7: [],
  8: [],
  9: [
    { title: "Quadratic Explorer", chapter: "Ch 4 · Quadratic Equations", description: "Drag the sliders for a, b and c and watch the parabola and its roots move live.", url: "quadratic-explorer.html" },
  ],
  10: [],
};
